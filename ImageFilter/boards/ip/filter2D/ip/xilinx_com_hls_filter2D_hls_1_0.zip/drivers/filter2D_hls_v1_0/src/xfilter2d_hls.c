// ==============================================================
// File generated on Fri Mar 26 13:53:23 +0100 2021
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xfilter2d_hls.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFilter2d_hls_CfgInitialize(XFilter2d_hls *InstancePtr, XFilter2d_hls_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_bus_BaseAddress = ConfigPtr->Control_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFilter2d_hls_Start(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL) & 0x80;
    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFilter2d_hls_IsDone(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFilter2d_hls_IsIdle(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFilter2d_hls_IsReady(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFilter2d_hls_EnableAutoRestart(XFilter2d_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL, 0x80);
}

void XFilter2d_hls_DisableAutoRestart(XFilter2d_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_AP_CTRL, 0);
}

void XFilter2d_hls_Set_rows(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_ROWS_DATA, Data);
}

u32 XFilter2d_hls_Get_rows(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_ROWS_DATA);
    return Data;
}

void XFilter2d_hls_Set_cols(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_COLS_DATA, Data);
}

u32 XFilter2d_hls_Get_cols(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_COLS_DATA);
    return Data;
}

void XFilter2d_hls_Set_channels(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_CHANNELS_DATA, Data);
}

u32 XFilter2d_hls_Get_channels(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_CHANNELS_DATA);
    return Data;
}

void XFilter2d_hls_Set_mode(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_MODE_DATA, Data);
}

u32 XFilter2d_hls_Get_mode(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_MODE_DATA);
    return Data;
}

void XFilter2d_hls_Set_r1_V(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_R1_V_DATA, Data);
}

u32 XFilter2d_hls_Get_r1_V(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_R1_V_DATA);
    return Data;
}

void XFilter2d_hls_Set_r2_V(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_R2_V_DATA, Data);
}

u32 XFilter2d_hls_Get_r2_V(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_R2_V_DATA);
    return Data;
}

void XFilter2d_hls_Set_r3_V(XFilter2d_hls *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_R3_V_DATA, Data);
}

u32 XFilter2d_hls_Get_r3_V(XFilter2d_hls *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_R3_V_DATA);
    return Data;
}

void XFilter2d_hls_InterruptGlobalEnable(XFilter2d_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_GIE, 1);
}

void XFilter2d_hls_InterruptGlobalDisable(XFilter2d_hls *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_GIE, 0);
}

void XFilter2d_hls_InterruptEnable(XFilter2d_hls *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_IER);
    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_IER, Register | Mask);
}

void XFilter2d_hls_InterruptDisable(XFilter2d_hls *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_IER);
    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_IER, Register & (~Mask));
}

void XFilter2d_hls_InterruptClear(XFilter2d_hls *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFilter2d_hls_WriteReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_ISR, Mask);
}

u32 XFilter2d_hls_InterruptGetEnabled(XFilter2d_hls *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_IER);
}

u32 XFilter2d_hls_InterruptGetStatus(XFilter2d_hls *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFilter2d_hls_ReadReg(InstancePtr->Control_bus_BaseAddress, XFILTER2D_HLS_CONTROL_BUS_ADDR_ISR);
}

