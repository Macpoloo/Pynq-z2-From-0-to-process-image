// ==============================================================
// File generated on Fri Mar 26 13:53:23 +0100 2021
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XFILTER2D_HLS_H
#define XFILTER2D_HLS_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfilter2d_hls_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_bus_BaseAddress;
} XFilter2d_hls_Config;
#endif

typedef struct {
    u32 Control_bus_BaseAddress;
    u32 IsReady;
} XFilter2d_hls;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFilter2d_hls_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFilter2d_hls_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFilter2d_hls_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFilter2d_hls_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XFilter2d_hls_Initialize(XFilter2d_hls *InstancePtr, u16 DeviceId);
XFilter2d_hls_Config* XFilter2d_hls_LookupConfig(u16 DeviceId);
int XFilter2d_hls_CfgInitialize(XFilter2d_hls *InstancePtr, XFilter2d_hls_Config *ConfigPtr);
#else
int XFilter2d_hls_Initialize(XFilter2d_hls *InstancePtr, const char* InstanceName);
int XFilter2d_hls_Release(XFilter2d_hls *InstancePtr);
#endif

void XFilter2d_hls_Start(XFilter2d_hls *InstancePtr);
u32 XFilter2d_hls_IsDone(XFilter2d_hls *InstancePtr);
u32 XFilter2d_hls_IsIdle(XFilter2d_hls *InstancePtr);
u32 XFilter2d_hls_IsReady(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_EnableAutoRestart(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_DisableAutoRestart(XFilter2d_hls *InstancePtr);

void XFilter2d_hls_Set_rows(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_rows(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_Set_cols(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_cols(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_Set_channels(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_channels(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_Set_mode(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_mode(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_Set_r1_V(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_r1_V(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_Set_r2_V(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_r2_V(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_Set_r3_V(XFilter2d_hls *InstancePtr, u32 Data);
u32 XFilter2d_hls_Get_r3_V(XFilter2d_hls *InstancePtr);

void XFilter2d_hls_InterruptGlobalEnable(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_InterruptGlobalDisable(XFilter2d_hls *InstancePtr);
void XFilter2d_hls_InterruptEnable(XFilter2d_hls *InstancePtr, u32 Mask);
void XFilter2d_hls_InterruptDisable(XFilter2d_hls *InstancePtr, u32 Mask);
void XFilter2d_hls_InterruptClear(XFilter2d_hls *InstancePtr, u32 Mask);
u32 XFilter2d_hls_InterruptGetEnabled(XFilter2d_hls *InstancePtr);
u32 XFilter2d_hls_InterruptGetStatus(XFilter2d_hls *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
